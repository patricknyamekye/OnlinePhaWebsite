
import AllNews from '../components/AllNews/AllNews'
import NavbarComponents from '../components/NavbarComponents/NavbarComponents'

const AllNewsPages = () => {
  return (
<>
<NavbarComponents/>
<br />
<br />
<br />
<AllNews/>
</>
  )
}

export default AllNewsPages