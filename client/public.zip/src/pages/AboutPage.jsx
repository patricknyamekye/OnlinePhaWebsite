import AboutUs from "../components/AboutUsComponents/AboutUs"
import Footer from "../components/FooterComponent/Footer"
import NavbarComponents from "../components/NavbarComponents/NavbarComponents"

const AboutPage = () => {
  return (
   <>
   
   < NavbarComponents/>
<br />
<br />
<br />



   <  AboutUs/>
   < Footer/>
   </>
  )
}

export default AboutPage