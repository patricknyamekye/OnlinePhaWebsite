import React from 'react';
import CheckoutComponent from '../components/CheckoutComponent/CheckoutComponent';

const CheckoutPage = () => {
  return <CheckoutComponent />;
};

export default CheckoutPage;