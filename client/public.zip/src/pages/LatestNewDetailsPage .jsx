
import LatestNewDetails from '../components/LatestNewDetails/LatestNewsDetails'

import NavbarComponents from '../components/NavbarComponents/NavbarComponents'

const LatestNewDetailsPage  = () => {
  return (
   <>
   <NavbarComponents/>
   <br />
   <br />
   <br />
   <br />
   <br />
     <LatestNewDetails/>

   
   </>
  )
}

export default LatestNewDetailsPage 