import React from 'react';
import { useParams } from 'react-router-dom';
import TrackComponent from '../components/TrackComponent/TrackComponent';

const TrackingPage = () => {

  return (
    <div>
      <TrackComponent />
    </div>
  );
};

export default TrackingPage;
