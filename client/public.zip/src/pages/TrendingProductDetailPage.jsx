
import NavbarComponents from "../components/NavbarComponents/NavbarComponents"
import TrendingProductDetails from "../components/TrendingDetails/TrendingProductDetails"

const ProductDetailPage = () => {
  return (
  <>
  <NavbarComponents/>
  <br />
  <br />

  <br />
  <br />
  <br />
  < TrendingProductDetails/>
  </>
  )
}

export default ProductDetailPage