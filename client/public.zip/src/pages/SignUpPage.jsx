
import Login from '../components/SignUpConponent/SignUp'


const SignUpPage = () => {
  
  return (
    <>
      
    < Login />
    
    </>
  )
}

export default SignUpPage